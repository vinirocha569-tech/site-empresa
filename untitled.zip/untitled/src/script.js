*{
  margin:0;
  padding:0;
  box-sizing:border-box;
}

body{
  font-family:Arial, sans-serif;
  background:#f5f5f5;
  color:#111;
}

header{
  display:flex;
  justify-content:space-between;
  align-items:center;

  padding:25px 10%;

  background:white;

  position:sticky;
  top:0;
}

.logo{
  font-size:28px;
  font-weight:bold;
}

nav a{
  margin-left:20px;
  text-decoration:none;
  color:#333;
}

.hero{
  height:90vh;

  display:flex;
  align-items:center;
  justify-content:center;

  text-align:center;

  padding:20px;
}

.hero-text span{
  color:#2563eb;
  font-weight:bold;
  letter-spacing:2px;
}

.hero-text h1{
  font-size:60px;
  margin:20px 0;
}

.hero-text p{
  font-size:20px;
  color:#555;
  margin-bottom:30px;
}

.btn{
  background:#2563eb;
  color:white;

  padding:15px 35px;

  text-decoration:none;

  border-radius:10px;

  display:inline-block;
}

.services{
  padding:100px 10%;

  text-align:center;
}

.services h2{
  font-size:40px;
  margin-bottom:50px;
}

.cards{
  display:grid;

  grid-template-columns:repeat(auto-fit,minmax(250px,1fr));

  gap:30px;
}

.card{
  background:white;

  padding:40px 30px;

  border-radius:20px;

  box-shadow:0 5px 15px rgba(0,0,0,0.05);
}

.card h3{
  margin-bottom:15px;
}

.portfolio{
  padding:100px 10%;
  text-align:center;
}

.projects{
  display:grid;

  grid-template-columns:repeat(auto-fit,minmax(250px,1fr));

  gap:30px;

  margin-top:50px;
}

.project{
  height:250px;

  background:white;

  border-radius:20px;

  display:flex;
  align-items:center;
  justify-content:center;

  font-size:24px;
  font-weight:bold;

  box-shadow:0 5px 15px rgba(0,0,0,0.05);
}

.contact{
  padding:100px 10%;
  text-align:center;
}

.contact h2{
  font-size:40px;
  margin-bottom:20px;
}

footer{
  padding:30px;
  text-align:center;
  background:white;
  margin-top:50px;
}

@media(max-width:768px){

  header{
    flex-direction:column;
    gap:20px;
  }

  .hero-text h1{
    font-size:42px;
  }

}